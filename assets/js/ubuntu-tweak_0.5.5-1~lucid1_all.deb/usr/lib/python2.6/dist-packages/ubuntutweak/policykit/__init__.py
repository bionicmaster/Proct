from polkitbutton import PolkitButton
from dbusproxy import proxy, MAX_DBUS_TIMEOUT
